﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ballScript : MonoBehaviour
{
    private gameScript _gameScript;

    private static int _hitCount;
    private static int _shotCount;

    private const int MAX_SHOT_COUNT = 5;

    // Start is called before the first frame update
    void Awake()
    {
        _shotCount++;
        _gameScript = FindObjectOfType<gameScript>();
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {

        Debug.Log("Çarpısma Gerçekleşti!");
        if (collision.gameObject.tag == "enemy")
        {
            Debug.Log("Düsmanı vurdum!");

            if (++_hitCount >= MAX_SHOT_COUNT)
            {
                Destroy(collision.gameObject, 1);

            }
        }

        if (_shotCount >= MAX_SHOT_COUNT)
        {
            _gameScript.EndGame(_hitCount >= MAX_SHOT_COUNT);
            _hitCount = 0;
            _shotCount = 0;
        }

        Destroy(gameObject);

    }
}

