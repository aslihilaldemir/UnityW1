﻿using UnityEngine.SceneManagement;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class gameScript : MonoBehaviour
{
    public GameObject tank;
    public GameObject enemy;
    public GameObject[] enemies;
    public GameObject ball;
    public InputField hiztxt;
    public InputField acitxt;




    [SerializeField]
    private Text _gameEndText;

    [SerializeField]
    private GameObject _buttonGameObject;

    void Start()
    {

    }

    public void EndGame(bool value)
    {
        _gameEndText.text = value
            ? "Kazandınız"
            : "Kaybettiniz";
        _buttonGameObject.SetActive(true);
    }

    bool isright = true;

    void Update()
    {
        if (Input.GetKey(KeyCode.RightArrow))
        {
            if (!isright)
            {
                isright = true;
                tank.transform.localScale = new Vector3(1, 1, 1);
            }

            tank.transform.position += new Vector3(0.05f, 0, 0);
        }
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            if (isright)
            {
                isright = false;
                tank.transform.localScale = new Vector3(-1, 1, 1);
            }
            tank.transform.position -= new Vector3(0.05f, 0, 0);
        }
    }
    public void ateset()
    {

        float hiz = float.Parse(hiztxt.text);
        float aci = float.Parse(acitxt.text);
        float xdimension = hiz * Mathf.Cos(aci * Mathf.Deg2Rad);
        float ydimension = hiz * Mathf.Sin(aci * Mathf.Deg2Rad);
        Vector3 force = new Vector3(xdimension, ydimension, 0);

        GameObject ucobje = GameObject.Find("uc");


        ucobje.transform.parent.gameObject.transform.eulerAngles = new Vector3(0, 0, aci);
        GameObject newball = Instantiate(ball, ucobje.transform.position, Quaternion.identity);

        newball.GetComponent<Rigidbody2D>().AddForce(force);
        newball.GetComponent<Rigidbody2D>().gravityScale = 1;
    }

    public void RestartGame()
    {
        SceneManager.LoadSceneAsync(SceneManager.GetActiveScene().buildIndex);
    }
}
